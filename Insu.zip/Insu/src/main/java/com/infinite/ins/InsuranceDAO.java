
package com.infinite.ins;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import javax.persistence.Query;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;



public class InsuranceDAO {
	SessionFactory sessionFactory;
	
	public String generateLapsedId(){
		sessionFactory = SessionHelper.getConnection();
		
	Session session = sessionFactory.openSession();
		Criteria cr = session.createCriteria(LapsedPolicy.class);
		List<Lapsed> Lapsed = cr.list();
		if(Lapsed.size()==0){
			return "L001";
		}
		int id = Integer.parseInt(Lapsed.get(Lapsed.size()-1).getLapseId().substring(1));
		String lid = String.format("L%03d", ++id);
		return lid;
	}
	public String lapsMe(LapsedPolicy lapsedPolicy) {
		String id = generateLapsedId();
		sessionFactory = SessionHelper.getConnection();
		Session session = sessionFactory.openSession();
		lapsedPolicy.setLapsedStatus("LAPSED");
		lapsedPolicy.setLapsedId(id);
		double paidAmount = lapsRefundAmount(lapsedPolicy.getBookingId());
		double refundAmount = paidAmount/10;
		lapsedPolicy.setRefundAmount(refundAmount);
		Transaction transaction = session.beginTransaction();
		session.save(lapsedPolicy);
		transaction.commit();
		transaction = session.beginTransaction();
		BookingDetails bookingDetails = searchByBookId(lapsedPolicy.getBookingId());
		bookingDetails.setStatus(Status.LAPSED);
		session.update(bookingDetails);
		transaction.commit();
		return "Your Policy Lapsed and refund Settled...";
	}
	
	public double lapsRefundAmount(String bookId) {
		BookingDetails booking = searchByBookId(bookId);
		System.out.println(booking.getPolicyID());
		System.out.println(booking.getBookingDate());
		Policy policyData = searchById(booking.getPolicyID());
		System.out.println(policyData.getPremiumAmount());
		System.out.println(policyData.getPayMode());
		String sql = "select sum(totalAmountToPayInEveryMode) from Payment where bookingId='" +bookId + "'";
		sessionFactory = SessionHelper.getConnection();
		Session session = sessionFactory.openSession();
		org.hibernate.Query query = session.createQuery(sql);
		List<Double> list = query.list();
		Double amountPaid = (Double)list.get(0);
		return amountPaid;
	}
	public double lapsRenewAmount(String bookId) {
		BookingDetails booking = searchByBookId(bookId);
		System.out.println(booking.getPolicyID());
		System.out.println(booking.getBookingDate());
		Policy policyData = searchById(booking.getPolicyID());
		System.out.println(policyData.getPremiumAmount());
		System.out.println(policyData.getPayMode());
		String sql = "select sum(totalAmountToPayInEveryMode) from Payment where bookingId='" +bookId + "'";
		sessionFactory = SessionHelper.getConnection();
		Session session = sessionFactory.openSession();
		org.hibernate.Query query = session.createQuery(sql);
		List<Double> list = query.list();
		Double amountPaid = (Double)list.get(0);
		System.out.println(amountPaid);
		java.util.Date today = new java.util.Date();
		java.util.Date bookedDate = new java.util.Date(booking.getBookingDate().getTime());
		System.out.println(today.getYear()- bookedDate.getYear());
		int yrs = today.getYear() - bookedDate.getYear();
		double premiumTobePaid = yrs * policyData.getPremiumAmount();
		System.out.println("You need to pay actually  " +premiumTobePaid);
		System.out.println("Till Today you paid   " +amountPaid);
		double balanceAmount = premiumTobePaid - amountPaid;
	//	double waitAmount = policyData.getPremiumAmount() * 2;
		return balanceAmount;
	}
	public String lapsCheck(String bookId) {
		BookingDetails booking = searchByBookId(bookId);
		System.out.println(booking.getPolicyID());
		System.out.println(booking.getBookingDate());
		Policy policyData = searchById(booking.getPolicyID());
		System.out.println(policyData.getPremiumAmount());
		System.out.println(policyData.getPayMode());
		String sql = "select sum(totalAmountToPayInEveryMode) from Payment where bookingId='" +bookId + "'";
		sessionFactory = SessionHelper.getConnection();
		Session session = sessionFactory.openSession();
		org.hibernate.Query query = session.createQuery(sql);
		List<Double> list = query.list();
		Double amountPaid = (Double)list.get(0);
		System.out.println(amountPaid);
		java.util.Date today = new java.util.Date();
		java.util.Date bookedDate = new java.util.Date(booking.getBookingDate().getTime());
		System.out.println(today.getYear()- bookedDate.getYear());
		int yrs = today.getYear() - bookedDate.getYear();
		double premiumTobePaid = yrs * policyData.getPremiumAmount();
		System.out.println("You need to pay actually  " +premiumTobePaid);
		System.out.println("Till Today you paid   " +amountPaid);
		double balanceAmount = premiumTobePaid - amountPaid;
		double waitAmount = policyData.getPremiumAmount() * 2;
		String message ="";
		if (balanceAmount - waitAmount > 0) {
			message+="You are in Deficit...Action Required\n";
			message+="For Renew You need to pay  " +balanceAmount;
			System.out.println("You are in Deficit...Action Required");
			System.out.println("For Renew You need to pay  " +balanceAmount);
		} else {
			message = "Relax...This policy Lapse time not occurred still...";
		}
		return message;
	}
public String generatePaymentId() {
		
		sessionFactory = SessionHelper.getConnection();
		Session session = sessionFactory.openSession();
		Criteria cr = session.createCriteria(Payment.class);
		java.util.List<Payment> roomlist = cr.list();
		session.close();
		
		if(roomlist.size()==0) {
			return "Q001";
		}
		else {
		String id = roomlist.get(roomlist.size()-1).getPaymentntId();
		int id1 = Integer.parseInt(id.substring(1));
		id1++;
		String id2 = String.format("Q%03d", id1);
		return id2;
		}
	}

	
	//SearchpolicyId from policy table
	
	public Policy searchById(String policyId) {
		sessionFactory = SessionHelper.getConnection();
  		Session session = sessionFactory.openSession(); 
  		Criteria cr = session.createCriteria(Policy.class);
  		cr.add(Restrictions.eq("policyId", policyId));
  		List<Policy> PolicyList = cr.list();
  		return PolicyList.get(0);
	}
	
	public BookingDetails searchByBookId(String bid) {
		sessionFactory = SessionHelper.getConnection();
		Session session = sessionFactory.openSession();
		Criteria criteria = session.createCriteria(BookingDetails.class);
		criteria.add(Restrictions.eq("bookingId", bid));
		java.util.List<BookingDetails> BookIdlist = criteria.list();
		System.out.println(BookIdlist.size());
		BookingDetails booking = BookIdlist.get(0);
		return booking;
	}
	
	public String confirmPayment(Payment payment) {
		sessionFactory = SessionHelper.getConnection();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(payment);
		transaction.commit();
		return "Payment Processed Successfully...";
	}
	//payment information for making payment
	public Payment paymentInfo(String bid) {
		String pid = generatePaymentId();
		BookingDetails bookingDetails = searchByBookId(bid);
		String paymode = bookingDetails.getPayMode();
		Payment objPayment = new Payment();
		objPayment.setBookingId(bid);
		objPayment.setPaymentntId(pid);
		objPayment.setPolicyId(bookingDetails.getPolicyID());
		objPayment.setCustomerId(bookingDetails.getCustomerId());
		Policy objPolicy = searchById(bookingDetails.getPolicyID());
		double premiumAmount = objPolicy.getPremiumAmount();
		System.out.println("Premium  " +premiumAmount);
		double installment = 0;
		objPayment.setTotalAmountToPayInEveryMode(installment);
		java.util.Date utilToday = new java.util.Date();
		Date today = new Date(utilToday.getTime());
		objPayment.setPaymentDate(today);
		
		List<Payment> payments = searchPaymentBookId(bid);
		int count = payments.size();
		System.out.println("Count is  " +count);
		Date nextPayment;
		Date lastPayment;
		if (count==0) {
			if (paymode.equals("QUARTERLY")) {
				installment = premiumAmount/4;
				objPayment.setTotalAmountToPayInEveryMode(installment);
				lastPayment = bookingDetails.getBookingDate();
				 java.util.Date utilDate = new java.util.Date (lastPayment.getTime ());
				 SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");  
		          String strDate = sdf.format(utilDate);
			        //create instance of the Calendar class and set the date to the given date  
			        Calendar cal = Calendar.getInstance();  
			        try{  
			           cal.setTime(sdf.parse(strDate));  
			        }catch(ParseException e){  
			            e.printStackTrace();  
			         }  
			             
			        // use add() method to add the days to the given date  
			        cal.add(Calendar.MONTH, 3);  
			        String dateAfter = sdf.format(cal.getTime());  
			        try {
						utilDate = sdf.parse(dateAfter);
					} catch (ParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			       nextPayment = new Date(utilDate.getTime());
			       System.out.println("Next Payment is  " +nextPayment);
			       objPayment.setNextDayPayment(nextPayment);
			}
			if (paymode.toUpperCase().equals("HALFYEARLY")) {
				installment = premiumAmount/2;
				objPayment.setTotalAmountToPayInEveryMode(installment);
				System.out.println("Premium Inner " +premiumAmount);
				System.out.println("Installment  " +installment);
				lastPayment = bookingDetails.getBookingDate();
				 java.util.Date utilDate = new java.util.Date (lastPayment.getTime ());
				 SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");  
		          String strDate = sdf.format(utilDate);
			        //create instance of the Calendar class and set the date to the given date  
			        Calendar cal = Calendar.getInstance();  
			        try{  
			           cal.setTime(sdf.parse(strDate));  
			        }catch(ParseException e){  
			            e.printStackTrace();  
			         }  
			             
			        // use add() method to add the days to the given date  
			        cal.add(Calendar.MONTH, 6);  
			        String dateAfter = sdf.format(cal.getTime());  
			        try {
						utilDate = sdf.parse(dateAfter);
					} catch (ParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			       nextPayment = new Date(utilDate.getTime());
			       System.out.println("Next Payment is  " +nextPayment);
			       objPayment.setNextDayPayment(nextPayment);
			}

		
		} else {
			System.out.println("Already Exists Block");
			Payment lastRecord = payments.get(payments.size()-1);
			lastPayment = lastRecord.getNextDayPayment();
			System.out.println("Last Payment "+lastPayment);
			objPayment.setPaymentDate(lastPayment);
			System.out.println("Payment Q  " +paymode);
			if (paymode.equals("QUARTERLY")) {
				installment = premiumAmount/4;
				objPayment.setTotalAmountToPayInEveryMode(installment);
			//	lastPayment = bookingDetails.getBookingDate();
				 java.util.Date utilDate = new java.util.Date (lastPayment.getTime ());
				 SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");  
		          String strDate = sdf.format(utilDate);
			        //create instance of the Calendar class and set the date to the given date  
			        Calendar cal = Calendar.getInstance();  
			        try{  
			           cal.setTime(sdf.parse(strDate));  
			        }catch(ParseException e){  
			            e.printStackTrace();  
			         }  
			             
			        // use add() method to add the days to the given date  
			        cal.add(Calendar.MONTH, 3);  
			        String dateAfter = sdf.format(cal.getTime());  
			        try {
						utilDate = sdf.parse(dateAfter);
					} catch (ParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			       nextPayment = new Date(utilDate.getTime());
			       System.out.println("Next Payment is  " +nextPayment);
			       objPayment.setNextDayPayment(nextPayment);
			}
			if (paymode.toUpperCase().equals("HALFYEARLY")) {
				installment = premiumAmount/2;
				objPayment.setTotalAmountToPayInEveryMode(installment);
				System.out.println("Premium Inner " +premiumAmount);
				System.out.println("Installment  " +installment);
			//	lastPayment = bookingDetails.getBookingDate();
				System.out.println("Inner Last payment  " +lastPayment);
				objPayment.setPaymentDate(lastPayment);
				 java.util.Date utilDate = new java.util.Date (lastPayment.getTime ());
				 SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");  
		          String strDate = sdf.format(utilDate);
			        //create instance of the Calendar class and set the date to the given date  
			        Calendar cal = Calendar.getInstance();  
			        try{  
			           cal.setTime(sdf.parse(strDate));  
			        }catch(ParseException e){  
			            e.printStackTrace();  
			         }  
			             
			        // use add() method to add the days to the given date  
			        cal.add(Calendar.MONTH, 6);  
			        String dateAfter = sdf.format(cal.getTime());  
			        System.out.println(dateAfter);
			        try {
						utilDate = sdf.parse(dateAfter);
					} catch (ParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			       nextPayment = new Date(utilDate.getTime());
			       System.out.println("Next Payment is  " +nextPayment);
			       objPayment.setNextDayPayment(nextPayment);
			}
		}
		return objPayment; 
	}
	
	//searchBookingID from paymentTable
	public List<Payment> searchPaymentBookId(String bid) {
		sessionFactory = SessionHelper.getConnection();
		Session session = sessionFactory.openSession();
		Criteria criteria = session.createCriteria(Payment.class);
		criteria.add(Restrictions.eq("bookingId", bid));
		java.util.List<Payment> BookIdlist = criteria.list();
		return BookIdlist;
	}
	
//	//AmmountleftCalculation
//	public double amountLeftInTerm(double premiumAmount,double totalAmountPaidInTerm,String bookId){
//		sessionFactory=SessionHelper.getConnection();
//		Session session=sessionFactory.openSession();
//		Criteria cr = session.createCriteria(Payment.class);
//		Customer customer=new Customer();
//		Policy policy=new Policy();
//		Payment payment=new Payment();
//		BookingDetails booking=new BookingDetails();
//		
//		List<Payment> paymentList = searchPaymentBookId(bookId);
//		
//		if(paymentList.size()==0){
//			double amountLeftInTerm1=policy.getPremiumAmount()-payment.getTotalAmountToPayInEveryMode();
//			return amountLeftInTerm1;
//			// payment.setAmountLeftInTerm(amountLeftInTerm1);
//		}else{
//			String id = paymentList.get(paymentList.size()-1).getBookingId();
//			double amountLeftInTerm2=payment.getAmountLeftInTerm()-payment.getTotalAmountToPayInEveryMode();
//			 //payment.setAmountLeftInTerm(amountLeftInTerm2);
//			return amountLeftInTerm2; 
//		}
//		
//	}
	
//	//TotalAmountToPayInEveryMode
//	public double totalAmountToPayInEveryMode(double totalAmountToPayInEveryMode){
//		sessionFactory=SessionHelper.getConnection();
//		Session session=sessionFactory.openSession();
//		Policy policy=new Policy();
//		double totalAmountToPayInEveryMode1=policy.getInstallmentAmountPerPayMode();
//		return totalAmountToPayInEveryMode1;
//	}
	//nextPAyment
//	public Date nextDatepayment(Date nextpayment){
//		sessionFactory=SessionHelper.getConnection();
//		Session session=sessionFactory.openSession();
//		java.util.Date date= new java.util.Date();
//		Policy policy= new Policy();
//		Payment payment= new Payment();
//		//Calendar cal = Calendar.getInstance();
//		//cal.setTime(date);
//		java.util.Date nextpay=new Date(date.getTime());
//		Calendar calendar = Calendar.getInstance();
//		
//		if(policy.getPayMode()=="QUATERLY"){
////			Date nextpay=new Date(date.getTime());
////			Calendar calendar = Calendar.getInstance();
//		       //System.out.println("Current Date = " + calendar.getTime());
//		      // Add 3 months to the Calendar
//			nextpay= calendar.getTime();
//			calendar.add(Calendar.MONTH, 3);
//		  payment.setNextDayPayment(nextpay);
//			
//		}else if(policy.getPayMode()=="HALFYEARLY"){
//			nextpay= calendar.getTime();
//			calendar.add(Calendar.MONTH, 6);
//		   payment.setNextDayPayment(nextpay); 
//		}else if(policy.getPayMode()=="YEARLY"){
//			nextpay= calendar.getTime();
//			calendar.add(Calendar.MONTH, 12);
//		   payment.setNextDayPayment(nextpay);
//		}else{
//			
//		}
//		return nextpayment;
//		
//	}
	
	public Date convertDate(String strDate) throws ParseException {
		java.util.Date utilDate = new SimpleDateFormat("yyyy-MM-dd").parse(strDate);
		return new Date(utilDate.getTime());
	}
	
//	//finecalculation
//	public double fine(double fine){
//		sessionFactory=SessionHelper.getConnection();
//		Session session=sessionFactory.openSession();
//		Customer customer=new Customer();
//		Policy policy=new Policy();
//		Payment payment=new Payment();
//		long paydate=payment.getPaymentDate().getTime();
//		long nextpayDate=payment.getNextDayPayment().getTime();
//		double fine1=0;
//		if(paydate > nextpayDate){
////		double payAmt=policy.getInstallmentAmountPerPayMode();
//			double fine2=100;
//			fine2=fine1+fine2;
//		}
//		return fine;
//		
//
//	}
	
	//paymentAmount Calculation
	
//	public double paymentAmout(double paymentAmount,String bookId,double fine){
//		sessionFactory=SessionHelper.getConnection();
//		Session session=sessionFactory.openSession();
//		Criteria cr = session.createCriteria(Payment.class);
//		Customer customer=new Customer();
//		Policy policy=new Policy();
//		Payment payment=new Payment();
//		fine(fine);
//		
//		BookingDetails booking=new BookingDetails();
//		List<Payment> paymentList = searchPaymentBookId(bookId);
//		if(paymentList.size()==0){
//			long paydate=payment.getPaymentDate().getTime();
//			long nextpayDate=payment.getNextDayPayment().getTime();
//			
//			if(paydate < nextpayDate){
//			double paymentAmount1=policy.getInstallmentAmountPerPayMode();
//			return paymentAmount1;
//		}
//		}else{
//			String id = paymentList.get(paymentList.size()-1).getBookingId();
//			
//			double payAmount=policy.getInstallmentAmountPerPayMode()+fine;
//			return payAmount;
//			
//		}
//	
//	 return paymentAmount;
//	}
	
	//nextPayDate
	
	
//	//MakePayment
//	public String addPayments(Payment payment){
//		sessionFactory=SessionHelper.getConnection();
//		Session session=sessionFactory.openSession();
//		
//		String payId=generatePaymentId();
//		payment.setPaymentntId(payId);
//		
//		Criteria cr=session.createCriteria(Payment.class);
//		Customer customer=new Customer();
//		Policy policy=new Policy();
//		BookingDetails booking=new BookingDetails();
//		
////		String custId=booking.getCustomerId();
//		payment.setCustomerId(payment.getCustomerId());
//		
//		String bookid=payment.getBookingId();
//		String pId=   payment.getPolicyId();
//		policy=searchById(pId);
//	 
//		double alt=amountLeftInTerm(policy.getPremiumAmount(), payment.getTotalAmountToPayInEveryMode(), payment.getBookingId());
//		payment.setAmountLeftInTerm(alt);
//		
//		double totalAmtEvryMode=totalAmountToPayInEveryMode(policy.getInstallmentAmountPerPayMode());
//		payment.setTotalAmountToPayInEveryMode(totalAmtEvryMode);
//		
//		
//		org.hibernate.Transaction transaction=session.beginTransaction();
//		session.save(payment);
//		transaction.commit();
//		session.close();
//		return "Payment done successfully....";
//		
//		
//		}
	
	
}